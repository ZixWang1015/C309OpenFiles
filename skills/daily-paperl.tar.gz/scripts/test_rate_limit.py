#!/usr/bin/env python3
"""Rate limiting and retry mechanism verification test for auto-paper-collecter.

Tests the HTTP 429 handling logic with simulated responses and real API calls.
Usage: python3 test_rate_limit.py [--test-api] [--simulate]
"""
import argparse
import sys
import os
import time
import json
import gzip
import urllib.request
import urllib.error
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

_last_request_time = 0.0
_min_interval = 1.0


def _rate_limit():
    global _last_request_time
    now = time.time()
    elapsed = now - _last_request_time
    if elapsed < _min_interval:
        time.sleep(_min_interval - elapsed)
    _last_request_time = time.time()


def http_get_with_retry(url, headers=None, timeout=30, max_retries=3, base_delay=2.0):
    req = urllib.request.Request(url, headers={
        "User-Agent": "auto-paper-collecter-skill/1.0 (test)",
        "Accept-Encoding": "gzip", **(headers or {})})

    for attempt in range(max_retries + 1):
        _rate_limit()
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.decompress(raw)
                return raw.decode("utf-8", "replace"), r.status, dict(r.headers)
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < max_retries:
                retry_after = e.headers.get("Retry-After") if e.headers else None
                if retry_after:
                    try:
                        wait = float(retry_after)
                    except ValueError:
                        wait = base_delay * (2 ** attempt)
                else:
                    wait = base_delay * (2 ** attempt)
                print(f"  [429] attempt {attempt+1}/{max_retries}, wait {wait:.1f}s")
                time.sleep(wait)
                continue
            return "", e.code, dict(e.headers or {})
        except Exception as e:
            if attempt < max_retries:
                wait = base_delay * (2 ** attempt)
                print(f"  [error] {type(e).__name__}: {e}, retry in {wait:.1f}s")
                time.sleep(wait)
                continue
            return "", 0, {}

    return "", 0, {}


def test_rate_limit():
    print("=" * 60)
    print("Test 1: Rate Limiting (request interval enforcement)")
    print("=" * 60)
    global _last_request_time
    _last_request_time = 0.0

    times = []
    for i in range(5):
        _rate_limit()
        times.append(time.time())
        print(f"  Request {i+1}: {times[-1]:.3f}")

    intervals = [times[i+1] - times[i] for i in range(len(times)-1)]
    min_observed = min(intervals) if intervals else 0
    print(f"\n  Min interval observed: {min_observed:.3f}s (expected >= {_min_interval}s)")
    passed = min_observed >= _min_interval * 0.9
    print(f"  Result: {'PASS' if passed else 'FAIL'}")
    return passed


def test_exponential_backoff():
    print("\n" + "=" * 60)
    print("Test 2: Exponential Backoff Calculation")
    print("=" * 60)
    base_delay = 2.0
    delays = [base_delay * (2 ** i) for i in range(5)]
    print(f"  Base delay: {base_delay}s")
    print(f"  Delays: {[f'{d:.1f}s' for d in delays]}")
    expected = [2.0, 4.0, 8.0, 16.0, 32.0]
    passed = delays == expected
    print(f"  Result: {'PASS' if passed else 'FAIL'}")
    return passed


def test_arxiv_api():
    print("\n" + "=" * 60)
    print("Test 3: Real arXiv API Call (with rate limiting)")
    print("=" * 60)
    url = "http://export.arxiv.org/api/query?" + urllib.parse.urlencode({
        "search_query": 'all:"machine learning"',
        "start": 0, "max_results": 3,
        "sortBy": "submittedDate", "sortOrder": "descending"
    })
    print(f"  URL: {url[:80]}...")
    start = time.time()
    body, status, headers = http_get_with_retry(url, max_retries=2, base_delay=1.0)
    elapsed = time.time() - start
    print(f"  Status: {status}")
    print(f"  Elapsed: {elapsed:.2f}s")
    print(f"  Response length: {len(body)} chars")
    if body and "<entry>" in body:
        import re
        entries = re.findall(r"<entry>", body)
        print(f"  Entries found: {len(entries)}")
        passed = status == 200 and len(entries) > 0
    else:
        passed = status == 200 and len(body) > 0
    print(f"  Result: {'PASS' if passed else 'FAIL'}")
    return passed


def test_multiple_requests():
    print("\n" + "=" * 60)
    print("Test 4: Multiple Sequential Requests (rate limit enforcement)")
    print("=" * 60)
    global _last_request_time
    _last_request_time = 0.0

    queries = ["transformer", "attention", "bert"]
    results = []
    start = time.time()
    for i, q in enumerate(queries):
        url = "http://export.arxiv.org/api/query?" + urllib.parse.urlencode({
            "search_query": f'all:"{q}"',
            "start": 0, "max_results": 2,
            "sortBy": "submittedDate", "sortOrder": "descending"
        })
        t0 = time.time()
        body, status, _ = http_get_with_retry(url, max_retries=2, base_delay=1.0)
        t1 = time.time()
        results.append((q, status, len(body), t1 - t0))
        print(f"  [{i+1}] {q:15s} status={status} len={len(body):5d} time={t1-t0:.2f}s")

    total = time.time() - start
    print(f"\n  Total time: {total:.2f}s for {len(queries)} requests")
    expected_min = _min_interval * (len(queries) - 1)
    print(f"  Expected minimum: ~{expected_min:.1f}s (rate limiting overhead)")
    passed = total >= expected_min * 0.8
    print(f"  Result: {'PASS' if passed else 'FAIL'}")
    return passed


def main():
    parser = argparse.ArgumentParser(
        description="Test rate limiting and retry mechanism for auto-paper-collecter")
    parser.add_argument("--simulate", action="store_true", default=True,
                        help="Run simulation tests (default: True)")
    parser.add_argument("--test-api", action="store_true", default=False,
                        help="Run real API tests against arXiv (requires internet)")
    parser.add_argument("--interval", type=float, default=1.0,
                        help="Minimum interval between requests in seconds (default: 1.0)")
    args = parser.parse_args()

    global _min_interval
    _min_interval = args.interval

    print("auto-paper-collecter - Rate Limit & Retry Test Suite")
    print(f"Min request interval: {_min_interval}s")
    print(f"Test mode: {'simulation + real API' if args.test_api else 'simulation only'}")

    all_passed = True
    results = {}

    if args.simulate:
        results["rate_limit"] = test_rate_limit()
        results["exponential_backoff"] = test_exponential_backoff()

    if args.test_api:
        results["arxiv_api"] = test_arxiv_api()
        results["multiple_requests"] = test_multiple_requests()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    for name, passed in results.items():
        status = "PASS" if passed else "FAIL"
        print(f"  {name:30s} {status}")
        if not passed:
            all_passed = False

    print(f"\nOverall: {'ALL TESTS PASSED' if all_passed else 'SOME TESTS FAILED'}")
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
