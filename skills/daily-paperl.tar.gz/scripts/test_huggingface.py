#!/usr/bin/env python3
"""Test HuggingFace API connectivity with proxy support.

Usage:
    python test_huggingface.py              # use config.json proxy settings
    python test_huggingface.py --no-proxy   # force no proxy
    python test_huggingface.py --proxy http://127.0.0.1:7890  # custom proxy
"""
import argparse
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
import fetch


def test_huggingface(query="LLM", n=5):
    print(f"Testing HuggingFace API with query: '{query}'")
    print(f"Proxy: http={C._proxy_http}, https={C._proxy_https}")
    print(f"Timeout: {fetch._source_timeout('HuggingFace', 8)}s")
    print("-" * 60)

    start = time.time()
    try:
        results = fetch.src_huggingface(query, n)
        elapsed = time.time() - start
        if len(results) > 0:
            print(f"\n✓ SUCCESS! Got {len(results)} results in {elapsed:.2f}s")
            for i, r in enumerate(results[:3]):
                print(f"  {i+1}. {r['title'][:80]}")
                print(f"     {r['url']}")
            return True
        else:
            print(f"\n✗ NO RESULTS (empty response) in {elapsed:.2f}s")
            return False
    except Exception as e:
        elapsed = time.time() - start
        print(f"\n✗ FAILED after {elapsed:.2f}s: {e}")
        return False


def test_basic_url(url, label):
    print(f"\nTesting {label}: {url[:60]}...")
    start = time.time()
    try:
        txt = C.http_get(url, timeout=10)
        elapsed = time.time() - start
        if txt:
            print(f"  ✓ OK ({len(txt)} bytes, {elapsed:.2f}s)")
            return True
        else:
            print(f"  ✗ Empty response ({elapsed:.2f}s)")
            return False
    except Exception as e:
        elapsed = time.time() - start
        print(f"  ✗ Failed: {e} ({elapsed:.2f}s)")
        return False


def main():
    parser = argparse.ArgumentParser(description="Test HuggingFace connectivity")
    parser.add_argument("--no-proxy", action="store_true", help="Disable proxy")
    parser.add_argument("--proxy", type=str, default=None, help="Proxy URL (e.g. http://127.0.0.1:7890)")
    parser.add_argument("--query", type=str, default="LLM", help="Search query")
    parser.add_argument("--n", type=int, default=5, help="Number of results")
    args = parser.parse_args()

    C.load_rate_limit_config()
    C.load_proxy_config()

    if args.no_proxy:
        C.set_proxy(http=None, https=None)
        print("Proxy: disabled (--no-proxy)")
    elif args.proxy:
        C.set_proxy(http=args.proxy, https=args.proxy)
        print(f"Proxy: {args.proxy} (from --proxy)")
    else:
        print(f"Proxy: http={C._proxy_http}, https={C._proxy_https} (from config)")

    print("=" * 60)

    test_basic_url("https://huggingface.co", "HuggingFace homepage")
    test_basic_url("https://huggingface.co/api/papers/search?q=LLM&limit=1", "HuggingFace papers API")

    print("\n" + "=" * 60)
    print("Full HuggingFace source test:")
    print("=" * 60)
    success = test_huggingface(args.query, args.n)

    print("\n" + "=" * 60)
    if success:
        print("🎉 All tests passed! HuggingFace is working.")
        return 0
    else:
        print("❌ HuggingFace connection failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
