"""Shared helpers for the auto-paper-collecter skill. Python stdlib only."""
import os
import re
import time
import json
import gzip
import datetime as dt
import urllib.request
import urllib.parse
import urllib.error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # skill/
STATE = os.path.join(ROOT, "state")
DIGESTS = os.path.join(ROOT, "digests")

_last_request_time = 0.0
_min_interval = 1.0
_max_retries = 3
_base_delay = 2.0
_request_timeout = 15
_proxy_http = None
_proxy_https = None
_opener = None


def set_proxy(http=None, https=None):
    global _proxy_http, _proxy_https, _opener
    if http is not None:
        _proxy_http = http
    if https is not None:
        _proxy_https = https
    _opener = None


def load_proxy_config():
    cfg = config()
    proxy_cfg = cfg.get("proxy", {})
    if proxy_cfg:
        set_proxy(
            http=proxy_cfg.get("http"),
            https=proxy_cfg.get("https")
        )
        return
    env_http = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    env_https = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    env_all = os.environ.get("ALL_PROXY") or os.environ.get("all_proxy")
    if env_http or env_https or env_all:
        set_proxy(
            http=env_http or env_all,
            https=env_https or env_all
        )


def _get_opener():
    global _opener
    if _opener is None:
        handlers = []
        if _proxy_http or _proxy_https:
            proxy_dict = {}
            if _proxy_http:
                proxy_dict["http"] = _proxy_http
            if _proxy_https:
                proxy_dict["https"] = _proxy_https
            handlers.append(urllib.request.ProxyHandler(proxy_dict))
        _opener = urllib.request.build_opener(*handlers)
    return _opener


def set_rate_limit(interval=None, max_retries=None, base_delay=None, timeout=None):
    global _min_interval, _max_retries, _base_delay, _request_timeout
    if interval is not None:
        _min_interval = float(interval)
    if max_retries is not None:
        _max_retries = int(max_retries)
    if base_delay is not None:
        _base_delay = float(base_delay)
    if timeout is not None:
        _request_timeout = float(timeout)


def load_rate_limit_config():
    cfg = config()
    rl = cfg.get("rate_limit", {})
    if rl:
        set_rate_limit(
            interval=rl.get("min_interval"),
            max_retries=rl.get("max_retries"),
            base_delay=rl.get("base_delay"),
            timeout=rl.get("timeout")
        )


def _rate_limit():
    global _last_request_time
    now = time.time()
    elapsed = now - _last_request_time
    if elapsed < _min_interval:
        time.sleep(_min_interval - elapsed)
    _last_request_time = time.time()


def _ensure_dirs():
    os.makedirs(STATE, exist_ok=True)
    os.makedirs(DIGESTS, exist_ok=True)


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def save_json(path, data):
    _ensure_dirs()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def config():
    return load_json(os.path.join(STATE, "config.json"), {
        "keywords": [], "domain": "computer science",
        "sources": {"arXiv": True, "Crossref": True, "Semantic Scholar": True,
                    "GitHub": True, "HuggingFace": True, "PapersWithCode": True,
                    "RSS": True},
        "lookback_days": 5, "max_per_source": 15,
        "rss_feeds": ["http://export.arxiv.org/rss/cs.PL"],
    })


def http_get(url, headers=None, timeout=None, max_retries=None, base_delay=None):
    """GET a URL → decoded text (handles gzip). Returns '' on failure.

    Supports rate limiting, 429 retry with exponential backoff, and
    respects Retry-After response headers.
    """
    if timeout is None:
        timeout = _request_timeout
    if max_retries is None:
        max_retries = _max_retries
    if base_delay is None:
        base_delay = _base_delay

    req = urllib.request.Request(url, headers={
        "User-Agent": "auto-paper-collecter-skill/1.0",
        "Accept-Encoding": "gzip", **(headers or {})})

    for attempt in range(max_retries + 1):
        _rate_limit()
        try:
            opener = _get_opener()
            with opener.open(req, timeout=timeout) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.decompress(raw)
                return raw.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < max_retries:
                retry_after = e.headers.get("Retry-After") if e.headers else None
                if retry_after:
                    try:
                        wait = float(retry_after)
                    except ValueError:
                        wait = base_delay * (2 ** attempt)
                else:
                    wait = base_delay * (2 ** attempt)
                print(f"[fetch] HTTP 429 on {url[:60]}…, retrying in {wait:.1f}s "
                      f"(attempt {attempt+1}/{max_retries})")
                time.sleep(wait)
                continue
            if e.code >= 500 and attempt < max_retries:
                wait = base_delay * (2 ** attempt)
                print(f"[fetch] HTTP {e.code} on {url[:60]}…, retrying in {wait:.1f}s "
                      f"(attempt {attempt+1}/{max_retries})")
                time.sleep(wait)
                continue
            print(f"[fetch] GET failed {url[:80]}…: HTTP {e.code}")
            return ""
        except Exception as e:
            print(f"[fetch] GET failed {url[:80]}…: {e}")
            return ""

    return ""


def http_json(url, headers=None, timeout=None):
    txt = http_get(url, headers, timeout)
    try:
        return json.loads(txt) if txt else None
    except json.JSONDecodeError:
        return None


def qs(params):
    return urllib.parse.urlencode(params)


_norm = re.compile(r"[^a-z0-9一-鿿]+")


def dedup_key(item):
    if item.get("doi"):
        return "doi:" + item["doi"].lower()
    return "title:" + _norm.sub("", (item.get("title") or "").lower())[:80]


def today(tz_hours=8):
    return (dt.datetime.utcnow() + dt.timedelta(hours=tz_hours)).date().isoformat()
